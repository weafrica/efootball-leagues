-- Archived for institutional memory, NOT a replayable migration.
-- One-off correction applied directly to production on 2026-09-01.
-- Moved 3 misplaced week-2 players back to their correct tier, then
-- backfilled Tier 5's resulting gap from Tier 6's week-1 runner-up.

update ladder_memberships set league_id = '481c6a60-2ac3-474e-9ab7-77d197e096c2' -- tier 5
where user_id = 'ed91a2c2-d8f6-4f1f-8c5d-994caa7acb30' and week_number = 2 and status = 'active';

update ladder_memberships set league_id = '481c6a60-2ac3-474e-9ab7-77d197e096c2' -- tier 5
where user_id = '70c34d31-d513-413c-a1aa-781b8240ef41' and week_number = 2 and status = 'active';

update ladder_memberships set league_id = '10eb9be4-09b5-4107-a387-fc082fb37d11' -- tier 6
where user_id = '8521b088-0429-4c0d-b3d5-7b68b58ae7b5' and week_number = 2 and status = 'active';

update ladder_memberships set league_id = '10eb9be4-09b5-4107-a387-fc082fb37d11' -- tier 6
where user_id = '7b03a525-a103-4d6c-91cd-2165b50f76cf' and week_number = 2 and status = 'active';

-- Tier 5 backfill: no bid winner, so pull tier 6's week-1 runner-up (e9edbef2, 10 pts)
update ladder_memberships set league_id = '481c6a60-2ac3-474e-9ab7-77d197e096c2' -- tier 5
where user_id = 'e9edbef2-74a2-42b6-a55d-6630a88a383c' and week_number = 2 and status = 'active';

-- Note: fixture 3baa417c (e9edbef2's played match in tier 6) is left as-is -- it's tied
-- to a real reward payout via foreign key, and the match genuinely happened. It stays
-- as a historical record even though e9edbef2 has since moved tiers.

select _ladder_sync_fixtures_internal('d2d4bb99-47c8-4ab1-bfdd-6be15d71253f', 2); -- tier 4
select _ladder_sync_fixtures_internal('481c6a60-2ac3-474e-9ab7-77d197e096c2', 2); -- tier 5
select _ladder_sync_fixtures_internal('10eb9be4-09b5-4107-a387-fc082fb37d11', 2); -- tier 6
