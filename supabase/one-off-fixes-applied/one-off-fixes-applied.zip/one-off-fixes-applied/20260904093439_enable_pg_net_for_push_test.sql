-- Archived for institutional memory, NOT a replayable migration.
-- Applied directly to production on 2026-09-04.
--
-- RE-VERIFIED LIVE on 2026-09-11: despite the "test" name, this is NOT
-- disposable. pg_net (v0.20.4) is confirmed still installed and actively
-- used by _notify_match_push (called from the live match/push-notification
-- path) via net.http_post(). Do not drop this extension.

create extension if not exists pg_net with schema extensions;
