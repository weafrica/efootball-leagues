-- Archived for institutional memory, NOT a replayable migration.
-- One-off correction applied directly to production on 2026-09-01.
-- Player 953a1133 won a paid Tier 8 bid (2 nets) and was correctly
-- charged, but an earlier manual correction wrongly moved him to Tier 9
-- thinking he was a stuck relegation case. Restored his Tier 8 seat and
-- let the overflow rebalancer handle the resulting cascade.

update ladder_memberships
set league_id = '906eb873-7ecf-4e54-b8ca-11e85c380e92' -- Tier 8
where user_id = '953a1133-e843-43c4-b8e5-0b971e520324'
  and week_number = 2;

select _rebalance_ladder_overflow_internal(2);
