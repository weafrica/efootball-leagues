-- Archived for institutional memory, NOT a replayable migration.
-- One-off correction applied directly to production on 2026-09-01.
update ladder_memberships
set league_id = '01b9555a-ccee-452f-8566-48dbff8cdbbd' -- Tier 7
where user_id = '59e16cc1-bf98-4323-a14b-cbc93be2b74b' -- RecceADEL909
  and week_number = 2;

select _ladder_sync_fixtures_internal('01b9555a-ccee-452f-8566-48dbff8cdbbd', 2); -- Tier 7
select _ladder_sync_fixtures_internal('906eb873-7ecf-4e54-b8ca-11e85c380e92', 2); -- Tier 8, now down to 5
