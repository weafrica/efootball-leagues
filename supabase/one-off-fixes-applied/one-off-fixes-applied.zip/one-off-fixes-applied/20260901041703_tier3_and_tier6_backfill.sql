-- Archived for institutional memory, NOT a replayable migration.
-- One-off correction applied directly to production on 2026-09-01.
-- Backfilled Tier 3 and Tier 6 gaps from the next tier down's best
-- remaining week-1 scorer (no bid winner in either case).

update ladder_memberships set league_id = (select id from ladder_leagues where tier = 3)
where user_id = '087b0b59-a2a8-4ff9-a182-9c15a71a408f' and week_number = 2 and status = 'active'; -- Rasekele123

update ladder_memberships set league_id = (select id from ladder_leagues where tier = 6)
where user_id = '5e67f79b-6d25-4ae7-8e33-ccdae1348f12' and week_number = 2 and status = 'active'; -- RAZORX25K

select _ladder_sync_fixtures_internal(id, 2) from ladder_leagues where tier in (3,4,6,7);
