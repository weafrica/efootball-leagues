-- Archived for institutional memory, NOT a replayable migration.
-- One-off correction applied directly to production on 2026-09-01.
-- Tier 8 at 5/6, no bid winner. Only eligible pull was NomercyGH
-- (Tier 9's other stayer, OFORIE20, was committed by his own winning bid).

update ladder_memberships
set league_id = '906eb873-7ecf-4e54-b8ca-11e85c380e92' -- Tier 8
where user_id = '23fdeec4-877b-4101-b3ae-0e5d40284aa9' -- NomercyGH
  and week_number = 2;

select _ladder_sync_fixtures_internal('906eb873-7ecf-4e54-b8ca-11e85c380e92', 2); -- Tier 8
select _ladder_sync_fixtures_internal('27eb071d-89f3-4026-bf32-500301b0350e', 2); -- Tier 9, now down to 5
