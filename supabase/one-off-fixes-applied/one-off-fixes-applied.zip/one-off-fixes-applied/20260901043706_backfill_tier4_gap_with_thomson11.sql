-- Archived for institutional memory, NOT a replayable migration.
-- One-off correction applied directly to production on 2026-09-01.
-- Tier 4 sat at 5/6 (knock-on cost of the Sambulo correction). No bid
-- winner, so pulled Tier 5's week-1 runner-up (ThomSon11, 3 pts).

update ladder_memberships
set league_id = 'd2d4bb99-47c8-4ab1-bfdd-6be15d71253f' -- Tier 4
where user_id = (select user_id from profiles where efootball_username = 'ThomSon11')
  and week_number = 2;

select _ladder_sync_fixtures_internal('d2d4bb99-47c8-4ab1-bfdd-6be15d71253f', 2);
select _ladder_sync_fixtures_internal('481c6a60-2ac3-474e-9ab7-77d197e096c2', 2); -- Tier 5, now down to 5
