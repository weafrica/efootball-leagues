-- Archived for institutional memory, NOT a replayable migration.
-- One-off correction applied directly to production on 2026-09-07.
-- Two Tier 18 fixtures were left status='pending' despite each having an
-- approved result submission and a matching reward payout already
-- posted. Reconciled the fixture rows to match the payout already paid
-- out, rather than reverse real money already sent to two players.

update ladder_fixtures
set status = 'played',
    home_score = 3,
    away_score = 3,
    played_at = '2026-09-06 22:15:00.0455+00'
where id in (
  'c600b38e-b674-4adb-90e9-a8889969bc5b',
  'edf9bf76-75cd-45b3-8258-53ec2ca0dc07'
)
and status = 'pending';
