-- Archived for institutional memory, NOT a replayable migration.
-- One-off correction applied directly to production on 2026-09-01.
update ladder_memberships
set league_id = '27eb071d-89f3-4026-bf32-500301b0350e' -- Tier 9
where user_id = 'f6b47241-384d-4262-8a1b-12bf2f006b2c' -- LIONKING5050
  and week_number = 2;

select _ladder_sync_fixtures_internal('27eb071d-89f3-4026-bf32-500301b0350e', 2); -- Tier 9
select _ladder_sync_fixtures_internal('2e4877f8-0e8e-453a-b82e-a178bf4f7f62', 2); -- Tier 10, now down to 5
