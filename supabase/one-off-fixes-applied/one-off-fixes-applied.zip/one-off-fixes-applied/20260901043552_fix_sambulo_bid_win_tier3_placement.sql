-- Archived for institutional memory, NOT a replayable migration.
-- One-off correction applied directly to production on 2026-09-01.
-- SAMBULO12345 won a paid Tier 3 bid (15 nets) and was correctly charged,
-- but an earlier manual correction had wrongly moved him to Tier 4,
-- which in turn caused an unnecessary backfill of Rasekele123 into
-- Tier 3. Swapped both back since no week-2 fixtures had been played.

update ladder_memberships
set league_id = '6d07fd18-f19f-480c-8094-a1b8c64ffcc9' -- Tier 3
where user_id = 'a2d48754-889b-4d15-a42c-2e9ebaf8c98f' -- SAMBULO12345
  and week_number = 2;

update ladder_memberships
set league_id = 'd2d4bb99-47c8-4ab1-bfdd-6be15d71253f' -- Tier 4
where user_id = (select user_id from profiles where efootball_username = 'Rasekele123')
  and week_number = 2;

select _ladder_sync_fixtures_internal('6d07fd18-f19f-480c-8094-a1b8c64ffcc9', 2);
select _ladder_sync_fixtures_internal('d2d4bb99-47c8-4ab1-bfdd-6be15d71253f', 2);
