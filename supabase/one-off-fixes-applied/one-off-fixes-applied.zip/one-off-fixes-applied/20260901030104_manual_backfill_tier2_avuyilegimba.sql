-- Archived for institutional memory, NOT a replayable migration.
-- One-off correction applied directly to production on 2026-09-01.
-- Tier 2 sat at 5 for week 2 (short by exactly the Nikkodm departure, per
-- prior session's item 6 backfill). No bid winner for Tier 2 for week 2.
-- Per the same "no bid winner -> pull 2nd-best-by-week-1-points from the
-- tier below" rule used for Tier 1's backfill: Tier 3's week-1 standings
-- (rank1 RockaFela already promoted out) put Avuyilegimba 2nd (9 pts).
-- He's a confirmed, unencumbered Tier 3 stayer -- no won bid, no other
-- pending move -- so safe to pull up.
update ladder_memberships
set league_id = (select id from ladder_leagues where tier = 2)
where user_id = 'f3c392fc-40c6-4b3e-8011-7ba4920d81a8' -- Avuyilegimba
  and week_number = 2
  and league_id = (select id from ladder_leagues where tier = 3);

-- Regenerate week-2 fixtures for both affected leagues from their now-
-- correct rosters. Safe here specifically because both tiers' week-2
-- fixtures are 100% pending right now (verified before running this) --
-- _generate_round_robin_fixtures_internal only deletes pending rows, so
-- this would NOT be safe to run blind if any results were already in.
select _ladder_sync_fixtures_internal((select id from ladder_leagues where tier = 2), 2);
select _ladder_sync_fixtures_internal((select id from ladder_leagues where tier = 3), 2);
