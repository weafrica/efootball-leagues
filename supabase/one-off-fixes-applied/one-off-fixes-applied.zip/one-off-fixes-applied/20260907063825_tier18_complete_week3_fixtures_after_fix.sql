-- Archived for institutional memory, NOT a replayable migration.
-- One-off correction applied directly to production on 2026-09-07.
-- Completed Tier 18's week-3 fixture generation after the leg-blind
-- duplicate-check fix, once the reconciliation above cleared the way.

select _generate_round_robin_fixtures_internal(
  'a3f06641-8080-41e2-8017-550e43476f7a'::uuid,
  3,
  array['d17fecdc-5fc8-4d02-a64f-b8a054d706b0','7641594e-ced0-4aea-9dda-0961b193b4dc','c610d063-0d3f-4487-a098-aab5b35f216e','d1da048e-16cb-4c25-b188-d1c361335d4d','347ec239-c9cf-4dc7-aff4-325530085bdf','41355250-8ce6-4983-8b18-744b97467424','c59ea299-71a0-4eb6-a99e-aa2bcd3104b2']::uuid[]
) as inserted;
