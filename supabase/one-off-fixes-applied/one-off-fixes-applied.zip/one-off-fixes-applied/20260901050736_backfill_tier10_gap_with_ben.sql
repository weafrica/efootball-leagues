-- Archived for institutional memory, NOT a replayable migration.
-- One-off correction applied directly to production on 2026-09-01.
-- Tier 10 at 5/6. Tiers 11-13 were the drained tail of a consolidated
-- region; Ben was the only remaining eligible candidate below Tier 10.
-- Promoting him resolved both Tier 10's gap and his own "nobody to
-- play" problem in Tier 12.

update ladder_memberships
set league_id = '2e4877f8-0e8e-453a-b82e-a178bf4f7f62' -- Tier 10
where user_id = '13e7ab19-467d-4646-abce-07d906eb8864' -- Ben
  and week_number = 2;

select _ladder_sync_fixtures_internal('2e4877f8-0e8e-453a-b82e-a178bf4f7f62', 2); -- Tier 10
