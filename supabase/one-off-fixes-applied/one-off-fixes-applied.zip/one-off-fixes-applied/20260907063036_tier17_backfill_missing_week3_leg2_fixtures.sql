-- Archived for institutional memory, NOT a replayable migration.
-- One-off correction applied directly to production on 2026-09-07.
-- Tier 17 week 3 was missing leg 2 (15 fixtures) due to the leg-blind
-- duplicate check later fixed in 20260933. Nothing had been played yet,
-- so this was a clean backfill: mirrored each leg-1 fixture as leg 2
-- (home/away swapped), mapping leg-1 round order onto Tier 1's existing
-- leg-2 round times for consistent pacing.

with leg1_rounds as (
  select countdown_expires_at as leg1_time,
         dense_rank() over (order by countdown_expires_at) as rn
  from (select distinct countdown_expires_at from ladder_fixtures
        where league_id = 'f53a0d0c-986d-4a0f-9e48-1e74d56f3280' and week_number = 3 and leg = 1) x
),
leg2_template as (
  select countdown_expires_at as leg2_time,
         dense_rank() over (order by countdown_expires_at) as rn
  from (select distinct countdown_expires_at from ladder_fixtures
        where league_id = 'cb91dbd3-42cf-4ee8-9cf2-ba2b0f656425' and week_number = 3 and leg = 2) x
)
insert into ladder_fixtures (league_id, week_number, home_user_id, away_user_id, status, countdown_expires_at, leg)
select f.league_id, f.week_number, f.away_user_id, f.home_user_id, 'pending', t.leg2_time, 2
from ladder_fixtures f
join leg1_rounds r on r.leg1_time = f.countdown_expires_at
join leg2_template t on t.rn = r.rn
where f.league_id = 'f53a0d0c-986d-4a0f-9e48-1e74d56f3280' and f.week_number = 3 and f.leg = 1;
