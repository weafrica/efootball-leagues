-- Archived for institutional memory, NOT a replayable migration.
-- Applied directly to production on 2026-09-07.
--
-- RE-VERIFIED LIVE on 2026-09-11: despite the "test/probe" name, this was
-- the real production call that generated Tier 17's week-3 leg-1
-- fixtures (15 rows). It hit the leg-blind duplicate-check bug fixed in
-- 20260933, leaving leg 2 missing -- resolved by the very next entry,
-- 20260907063036. Current live state confirmed clean: 15 leg-1 + 15
-- leg-2 fixtures, no duplicates, no stray rows.

select _generate_round_robin_fixtures_internal(
  'f53a0d0c-986d-4a0f-9e48-1e74d56f3280'::uuid,
  3,
  array['66a98459-c81d-46f1-8329-73792b58d25e','4a89bc33-eeb1-48a4-98b4-b14ba5ae2213','2098a1aa-327a-45d0-a3f3-1e771e466f08','83e00e08-11b2-40b9-91d9-ce1c9c57fb57','285fa6f4-0aea-40ff-9ae6-bb1a70d01dea','e644b29a-d6de-421b-b48e-b8f4a4aaa1c3']::uuid[]
) as inserted;
