-- Archived for institutional memory, NOT a replayable migration.
-- One-off correction applied directly to production on 2026-09-01.
-- Fixed 3 players stuck after relegation who never actually moved down,
-- plus 1 wrongly-placed week-1 stayer, then let the overflow handler
-- cascade any resulting >6-player leagues.

update ladder_memberships set league_id = 'd2d4bb99-47c8-4ab1-bfdd-6be15d71253f'
where user_id = 'a2d48754-889b-4d15-a42c-2e9ebaf8c98f' and week_number = 2 and status = 'active'; -- SAMBULO12345 back to Tier 4

update ladder_memberships set league_id = (select id from ladder_leagues where tier = 8)
where user_id = 'f2f02aa2-75dd-4d6f-94ce-ccd71a16f67c' and week_number = 2 and status = 'active'; -- THAMI0505 -> Tier 8

update ladder_memberships set league_id = (select id from ladder_leagues where tier = 9)
where user_id = '953a1133-e843-43c4-b8e5-0b971e520324' and week_number = 2 and status = 'active'; -- -> Tier 9

update ladder_memberships set league_id = (select id from ladder_leagues where tier = 7)
where user_id = '5281a100-6c70-4619-a846-88bb8a04fb11' and week_number = 2 and status = 'active'; -- nopekid -> Tier 7

select _rebalance_ladder_overflow_internal(2);
select _ladder_sync_fixtures_internal(id, 2) from ladder_leagues where tier in (3,4,6,7,8,9);
