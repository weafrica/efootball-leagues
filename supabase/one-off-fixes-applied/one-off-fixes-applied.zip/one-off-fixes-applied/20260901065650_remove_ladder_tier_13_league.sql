-- Archived for institutional memory, NOT a replayable migration.
-- One-off cleanup applied directly to production on 2026-09-01.
-- Tier 13 was fully drained (0 players in week 2). Its only history was
-- 3 week-1 memberships and 6 forfeited fixtures -- no real matches played,
-- no fee events, no bids. Removed at user's request since no longer needed.

delete from ladder_fixtures where league_id = 'b88d3151-fbb3-49ac-aa66-29232b992941';
delete from ladder_memberships where league_id = 'b88d3151-fbb3-49ac-aa66-29232b992941';
delete from ladder_leagues where id = 'b88d3151-fbb3-49ac-aa66-29232b992941';
